#include "ActiveStatesManage.h"

ActiveStatesManage::~ActiveStatesManage(void)
{
}
