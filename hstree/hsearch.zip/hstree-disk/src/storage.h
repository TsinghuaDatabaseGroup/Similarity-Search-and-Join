/*
 * storage.h
 *
 *  Created on: 2014-12-11
 *      Author: wangjin
 */

#ifndef STORAGE_H_
#define STORAGE_H_
#include "util.h"

void readData(const char* path);
void readQuery(const char* path);
void saveList(ofstream &pf, std::vector<int>& list);
void loadList(ifstream &pf, std::vector<int>& list);
void saveaddrList(ofstream &pf, std::vector<ADDR>& list);
void loadaddrList(ifstream &pf, std::vector<ADDR>& list);
#endif /* STORAGE_H_ */
