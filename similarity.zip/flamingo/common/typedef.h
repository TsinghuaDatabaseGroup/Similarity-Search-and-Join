/*
  $Id: typedef.h 5714 2010-09-09 03:51:02Z abehm $

  Copyright (C) 2010 by The Regents of the University of California

  Redistribution of this file is permitted under the terms of the 
  BSD license.

  Date: 04/17/2008
  Author: Rares Vernica <rares (at) ics.uci.edu> 
*/

#ifndef _typedef_h_
#define _typedef_h_

typedef unsigned uint;
typedef unsigned char uchar;

#endif
