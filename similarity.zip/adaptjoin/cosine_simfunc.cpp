#include "cosine_simfunc.h"


CosineSimFunc::CosineSimFunc(void)
{
}

CosineSimFunc::~CosineSimFunc(void)
{
}
