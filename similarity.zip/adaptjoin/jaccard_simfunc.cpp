#include "jaccard_simfunc.h"

JaccardSimFunc::JaccardSimFunc(void)
{
}

JaccardSimFunc::~JaccardSimFunc(void)
{
}
