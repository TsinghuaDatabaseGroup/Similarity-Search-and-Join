#include "simfunc.h"

SimFunc::SimFunc(void)
{
}

SimFunc::~SimFunc(void)
{
}
