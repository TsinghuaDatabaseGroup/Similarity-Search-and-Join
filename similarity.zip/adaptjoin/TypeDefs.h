#pragma once

//#define SDL
typedef unsigned int uint;
typedef unsigned char uchar;
typedef unsigned int  scoretype;
typedef unsigned short int usint;
const double eps = 1e-6;

