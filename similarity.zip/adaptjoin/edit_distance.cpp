#include "edit_distance.h"

uchar EditDistance::matrix1[MAX_STRING_LEN+1];
uchar EditDistance::matrix2[MAX_STRING_LEN+1];
