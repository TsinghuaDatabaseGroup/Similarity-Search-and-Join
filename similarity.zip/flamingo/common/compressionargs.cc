/*
  $Id: compressionargs.cc 3642 2008-07-10 22:31:52Z rares $

  Copyright (C) 2010 by The Regents of the University of California
 
  Redistribution of this file is permitted under the terms of the
  Academic BSD license.

  Date: 06/25/2008
  Author: Rares Vernica <rares (at) ics.uci.edu>
*/

#include "compressionargs.h"
