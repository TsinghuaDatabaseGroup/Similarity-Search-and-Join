#include "AdvancedStack.h"


AdvancedStack::~AdvancedStack(void)
{
}
