#include "Tokenizer.h"

Tokenizer::Tokenizer(void)
{
}

Tokenizer::~Tokenizer(void)
{
}
