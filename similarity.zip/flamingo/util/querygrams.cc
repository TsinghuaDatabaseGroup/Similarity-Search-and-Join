/*
  $Id: querygrams.cc 5713 2010-09-09 03:11:22Z abehm $

  Copyright (C) 2010 by The Regents of the University of California
 
  Redistribution of this file is permitted under the terms of the BSD
  license.

  Date: 11/07/2008
  Author: Rares Vernica <rares (at) ics.uci.edu>
*/

#include "querygrams.h"
