#include "reverse_delta_inverted_index.h"

