#include "dice_simfunc.h"

DiceSimFunc::DiceSimFunc(void)
{
}

DiceSimFunc::~DiceSimFunc(void)
{
}
